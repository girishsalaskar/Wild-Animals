function msvr()
{
switch(msvr.arguments[0])
{
case 1:
{
ihm.src="bt/m/hm.gif"
break
}

case 2:
{
ias.src="bt/m/as.gif"
break
}

case 3:
{
icl.src="bt/m/cl.gif"
break
}

case 4:
{
ian.src="bt/m/an.gif"
break
}

case 5:
{
ibd.src="bt/m/bd.gif"
break
}

case 6:
{
ifs.src="bt/m/fs.gif"
break
}

case 7:
{
ipg.src="bt/m/pg.gif"
break
}

default:
{
alert("Greater than 1")
}
}
}

function msot()
{
switch(msot.arguments[0])
{
case 1:
{
ihm.src="bt/n/hm.gif"
break
}

case 2:
{
ias.src="bt/n/as.gif"
break
}

case 3:
{
icl.src="bt/n/cl.gif"
break
}

case 4:
{
ian.src="bt/n/an.gif"
break
}

case 5:
{
ibd.src="bt/n/bd.gif"
break
}

case 6:
{
ifs.src="bt/n/fs.gif"
break
}

case 7:
{
ipg.src="bt/n/pg.gif"
break
}

default:
{
alert("Greater than 1")
}
}
}